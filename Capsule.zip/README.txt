
CMPT362 Group 10 — Capsule 

Note: The APK must be run on a physical phone for the camera feature to work. This is due a limitation of the CameraX library, which is not compatible with the Android Studio emulator. We tested our app with a Samsung Galaxy S10.

API Key for WeatherMap API (put in local.properties if missing):

API_KEY=500de63fee376381d50c5e71803fc4d7